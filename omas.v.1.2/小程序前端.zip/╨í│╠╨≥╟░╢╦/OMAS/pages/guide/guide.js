  // pages/guide/guide.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    maps:{
      mapid:'',
      startpoint:'',
      endpoint:'',
      url:''
    },
    start: ['呼吸科','妇科'],
    end:['药房','呼吸科','取药点'],
    select:['','']
  },
  // test(e){
  //   wx.request({
  //     url: app.golbalData.url+'/wxpatient/getMap',
  //     data:this.data.maps,
  //     method:'post',
  //     success:res=>{
  //       console.log(res)
  //     }
  //   })
  // },
  tap(e){
    wx.previewImage({
      urls: [this.data.maps.url],
    })
  },
  startChange(e){
    var  that = this;
    let maps= that.data.maps;
    var select = this.data.select;
    select[0] = e.detail.value;
    maps.startpoint = that.data.start[e.detail.value];
    that.setData({
      select:select,
      maps:maps
    })
    // console.log(maps)
  },
  endChange(e){
    var that = this;
    let maps = that.data.maps;
    var select = this.data.select;
    select[1] = e.detail.value;
    maps.endpoint = that.data.end[e.detail.value];
    that.setData({
      select: select,
      maps: maps
    })
    wx.request({
      url: app.globalData.url+'/wxpatient/getMap',
      data:this.data.maps,
      header:{
        token:app.globalData.token
      },
      method:'post',
      success:res=>{
        var map=res.data.message.map;
        map.url = app.globalData.url+map.url;
        that.setData({
          maps:res.data.message.map
        })
        console.log(res)
      }
    })
    console.log(maps)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  }

})