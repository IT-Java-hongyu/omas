// pages/tag/tag.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        tagList: null,
        chooseList: [],
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var that = this;
        wx.request({
            url: 'http://localhost:8080/omas.v.1.2/wxApartment/getAllTags',
            success: function(res) {
                that.setData({
                    tagList: res.data
                })
                console.log(res.data)
            }
        })
    },
    tagTap: function(event) {
        var that = this;
        var id = event.currentTarget.dataset.id
        var tagList = that.data.tagList
        var chooseList = that.data.chooseList
        for (let i = 0; i < tagList.length; i++) {
            if (tagList[i].tagId == id) {
                chooseList.push(tagList[i])
                tagList.splice(i, 1)
                console.log('add')
            }
        }
        console.log(tagList)
        that.setData({
            tagList: tagList,
            chooseList: chooseList
        })
    },
    tagDelete: function(event) {
        var that = this;
        var id = event.currentTarget.dataset.id
        var tagList = that.data.tagList
        var chooseList = that.data.chooseList
        for (let i = 0; i < chooseList.length; i++) {
            if (chooseList[i].tagId == id) {
                tagList.push(chooseList[i])
                chooseList.splice(i, 1)
                console.log('delete')
            }
        }
        console.log(tagList)
        that.setData({
            tagList: tagList,
            chooseList: chooseList
        })
    },
    goNext: function() {
        wx.showLoading({
                title: '为您推荐诊室',
                mask: true
            })
            //mask是防止屏幕穿透的，默认是false
        var chooseList = this.data.chooseList
        var tags = {}
        tags.tags = chooseList
        wx.request({
            url: `http://localhost:8080/omas.v.1.2/wxApartment/getRankedApartment`,
            method: 'POST',
            data: tags,
            success: function(res) {
                wx.hideLoading();
                wx.navigateTo({
                    url: '../queue/queue',
                    success(ret) {
                        ret.eventChannel.emit('rankedApartment', res.data)
                    }
                })
            },
            false: function(err) {
                wx.hideLoading()
                wx.showToast({
                    title: '服务器错误',
                    icon: 'none',
                    duration: '1000'
                })
            }
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})