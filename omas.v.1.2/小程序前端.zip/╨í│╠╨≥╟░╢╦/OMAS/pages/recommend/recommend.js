// pages/recommend/recommend.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showModal:false,
    url: "https://ossweb-img.qq.com/images/lol/web201310/skin/big10001.jpg",
    apartment: [{
      apartId: "",
      apartName: "",
    }],
    apartArr:['全部科室'],
    date: "2019-12-12",
    title: {
      titleId: "",
      titleName: "",
    },
    specialty: [''],
    doctor: [],
    select:['','',''],
    tap:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    //获取所有医生列表
    wx.request({
      url: app.globalData.url +'/wxDoctor/getAllDoctorInformation',
      method:'post',
      header: {
        token: app.globalData.token
      },
      success:res =>{
        console.log(res);
        that.setData({
          doctor:res.data.docList
        })
      }
    }),
    //获取所有科室列表
    wx.request({
      url: app.globalData.url +'/wxApartment/getAllApartment',
      method: 'post',
      header: {
        token: app.globalData.token
      },
      success: res => {
        // console.log(res);
        var arr = ['全部科室'];
        var list = res.data.apartmentList;
        for (var i in list){
          arr.push(list[i].apartName);
        }
        // console.log(arr);
        that.setData({
          apartment: list,
          apartArr:arr
        });
      }
    });
    //获取所有医生特长列表
    wx.request({
      url: app.globalData.url +'/wxSpecialty/getAllSpecialty',
      method: 'post',
      header: {
        token: app.globalData.token
      },
      success: res => {
        // console.log(res);
        var arr = ['全部'];
        var list = res.data.specialtyList;
        for (var i  in list) {
          arr.push(list[i].describe);
        }
        // console.log(arr);
        that.setData({
          specialty: arr
        });
      }
    });
    
  },
  //特长选择
  specialtyChange:function(e){
    var that = this;
    var arr = this.data.select;
    arr[1] = this.data.specialty[e.detail.value];
    that.setData({
      specialtyIndex: e.detail.value,
      select: arr
    });
    that.getDocList();
    console.log(arr)
  },
  //科室选择
  apartChange:function(e){
    var that = this;
    var arr = this.data.select;
    console.log(e.detail.value)
    arr[0] = e.detail.value==0?'':this.data.apartment[e.detail.value-1].apartId;
    that.setData({
      apartIndex: e.detail.value,
      select: arr
    });
    that.getDocList();
    console.log(this.data.select)
  },
  //时间选择
  dateChange:function(e){
    var that = this;
    var arr = this.data.select;
    arr[2] = e.detail.value;
    that.setData({
      date: e.detail.value,
      select: arr
    })
    that.getDocList();
    console.log(that.data.select)
  },
  //条件获取医生列表
  getDocList:function(){
    var that = this;
    var id = that.data.select[0];
    var symptoms = that.data.select[1] ;
    var date = that.data.select[2];
    let data={
      apartment: {
        apartId: id,
        apartName: "",
        typicalSymptom: ""
      },
      date: date,
      title: {
        titleId: "",
        titleName: "",
      },
      symptoms: symptoms,
      doctor: []
    }
    console.log(data)
    wx.request({
      url: app.globalData.url +'/wxpatient/searchDoctorList',
      method:'post',
      data:data,
      header: {
        token: app.globalData.token
      },
      success:res =>{
        that.setData({
          doctor: res.data.doctor
        })
        console.log(this.data.doctor)
      }
    })
  },
  showDoc:function(e){
    this.setData({
      showModal: true,
      tap:e.currentTarget.id
    })
    console.log(e)
  },
  hideModal(e){
    this.setData({
      showModal: false
    })
  },
  chooseDoctor(){
    var index = this.data.tap;
    var apartID = this.data.doctor[index].apartId;
    var docID = this.data.doctor[index].docId;
    console.log(apartID);
    console.log(docID);
    wx.request({
      url: 'http://localhost:8080/omas.v.1.2/wx/Guahao',
      header: {
        token: app.globalData.token
      },
      // method:'post',
      data: {
        apartId: apartID,
        doctorId: docID,
        patientId: app.globalData.patientId
      },
      success: res => {
        wx.navigateTo({
          url: '../queue/queue',
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
})