// pages/tip.js
const app = getApp();
Page({
    data: {
        status: [],
        bottom: app.bottom,
        StatusBar: app.globalData.StatusBar,
        CustomBar: app.globalData.CustomBar,
        apartment: [{
            apartId: "",
            apartName: "",
        }],
        docList: [{
            apartId: '',
            apartName: '',
            birthday: '',
            dateList: [],
            docId: '',
            docName: '',
            phone: '',
            sex: '',
            synopsis: '',
            tileId: '',
            tileName: ''
        }],
        multiArray: [
            [],
            [],
        ],
        multiIndex: [0, 0],
        selet: ['', ''],
        rankedApartment: null,
        rankedDoctor: null,
        hasScore: false,
    },

    MultiChange(e) {
        this.setData({
            multiIndex: e.detail.value
        })
    },
    MultiColumnChange(e) {
        let data = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        data.multiIndex[e.detail.column] = e.detail.value;
        let index = data.multiIndex[0];
        var apartment = this.data.apartment;
        console.log(index);
        this.getDoc(apartment[index].apartId);
        // this.setData(data);
        console.log(data.multiIndex);
    },
    onLoad: function() {

        var that = this;
        //获取推荐诊室
        const eventChannel = this.getOpenerEventChannel()
        eventChannel.on('rankedApartment', function(ret) {
            that.setData({
                rankedApartment: ret.apartmentList
            })
            console.log(ret.apartmentList)
        })

        wx.request({
            //获取所有科室
            url: app.globalData.url + '/wxApartment/getAllApartment',
            header: {
                token: app.globalData.token
            },
            success: res => {
                var apart = res.data.apartmentList;
                var apartArr = [];
                console.log(res);
                for (var i in apart) {
                    apartArr[i] = apart[i].apartName;
                };
                that.setData({
                    apartment: apart,
                    multiArray: [apartArr, []]
                });
                var apartId = apart[0].apartId;
                if (apartId) {
                    that.getDoc(apartId);
                }
                // console.log(this.data.apartment);
                // console.log(this.data.multiArray);
            },

        });
        that.checkGuohao();
    },
    checkGuohao() {
        wx.request({
            url: app.globalData.url + '/wx/checkGuahao',
            data: {
                patientId: app.globalData.patientId
            },
            header: {
                token: app.globalData.token
            },
            success: res => {
                var status = [0, 0, 0];
                status[2] = res.data.message.status;
                this.setData({
                    status: status
                })
                console.log(status);
                if (this.data.status[2] == 1) {
                    this.guahao();
                }
            },
        })
    },
    getDoc: function(apartId) {
        var that = this;
        wx.request({
            url: app.globalData.url + '/wxDoctor/getDoctorByApartId',
            data: {
                apartId: apartId
            },
            header: {
                token: app.globalData.token
            },
            success: res => {
                console.log(res);
                var docList = res.data.docList;
                var docArr = [];
                for (var i = 0; i < docList.length; i++) {
                    docArr.push(docList[i].docName)
                };
                // console.log(docArr);
                var apart = this.data.multiArray[0];
                that.setData({
                    docList: docList,
                    multiArray: [apart, docArr]
                })
            }
        })
    },
    getRankedDoc: function(apartId) {
        var that = this
        this.getDoc(apartId)
        wx.request({
            url: app.globalData.url + '/wxDoctor/getRankedDoctorByApartId',
            data: {
                apartId: apartId
            },
            header: {
                token: app.globalData.token
            },
            success: res => {
                that.setData({
                    rankedDoctor: res.data.docList
                })
            }
        })
    },
    /**
     * 点击推荐列表
     * @param {*} event 
     */
    chooseApartment: function(event) {
        var apartId = event.currentTarget.dataset.id
        console.log(apartId)
        var apartment = this.data.apartment
        var apartIndex = 0
        for (let i = 0; i < apartment.length; i++) {
            if (apartId == apartment[i].apartId) {
                apartIndex = i
            }
        }
        var multiIndex = this.data.multiIndex
        multiIndex[0] = apartIndex
        multiIndex[1] = null
        this.setData({
            multiIndex: multiIndex
        })
        this.getRankedDoc(apartId)
    },
    chooseDoctor: function(event) {
        var docId = event.currentTarget.dataset.id
        console.log(docId)
        var docList = this.data.docList
        var docIndex = 0
        for (let i = 0; i < docList.length; i++) {
            if (docId == docList[i].docId) {
                docIndex = i
            }
        }
        var multiIndex = this.data.multiIndex
        multiIndex[1] = docIndex
        this.setData({
            multiIndex: multiIndex
        })
    },
    bindScore: function(event) {
        var that = this
        var docIndex = this.data.multiIndex[1]
        console.log('docindex' + docIndex)
        console.log(this.data.docList[docIndex])
        var docId = this.data.docList[docIndex].docId
        var score = event.currentTarget.dataset.id
        wx.request({
            url: app.globalData.url + `/wxDoctor/updataDoctorScoreById?docId=${docId}&score=${score}`,
            header: {
                token: app.globalData.token
            },
            success: res => {
                that.setData({
                    hasScore: true
                })
            }
        })
    },
    guahao() {
        var apartIndex = this.data.multiIndex[0];
        var docIndex = this.data.multiIndex[1];
        // console.log(index);
        // console.log(this.data.docList[index].docId);
        wx.request({
            url: 'http://localhost:8080/omas.v.1.2/wx/Guahao',
            header: {
                token: app.globalData.token
            },
            // method:'post',
            data: {
                apartId: this.data.apartment[apartIndex].apartId,
                doctorId: this.data.docList[docIndex].docId,
                patientId: app.globalData.patientId
            },
            success: res => {
                var select = [];
                console.log(res)
                select[0] = res.data.message.apartment;
                select[1] = res.data.message.doctor;
                console.log(res)
                this.setData({
                    select: select,
                    status: res.data.message.status
                })
                console.log(this.data.status)
            }
        })
    }
})