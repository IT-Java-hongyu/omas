// pages/track/track.js
const app = getApp()
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    TabCur: 0,
    record:{},
    isUpdata:false,
    scrollLeft: 0,
    // symptomsList: [],
    change: ['消失', '轻微', '严重', '特别严重'],
    value: [],
    index: "",
    time:'06:00'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: app.globalData.url + '/wxpatient/searchSymptoms',
      data: {
        pid: app.globalData.patientId
        },
      header: {
        token: app.globalData.token
      },
      success: res => {
        this.setData({
          record: res.data
        })
        console.log(res);
        // console.log(this.data.symptomsList);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getTrack:function(){
    
  },

  tabSelect:function(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 1) * 60
    })
    console.log(this.data.TabCur);
  },
  swiperChange(e){
    this.setData({
      TabCur: e.detail.current,
      scrollLeft: (e.detail.current - 1) * 60
    })
    console.log(e)
  },
  showModal(e) {
    console.log(e)
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
    this.send(e.target.id)
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  true(e) {
    this.setData({
      modalName: null
    })
    console.log(e)
  },
  handleChange(e) {
    var value = this.data.value;
    var index = this.data.index;
    value[index] = e.detail.value;
    let record = this.data.record;
    record.rSymptomsList[index].nowDegree = e.detail.value;
    this.setData({
      value: value,
      record: record
    })
    console.log(this.data.record)
  },
  send(e) {
    this.setData({
      index: e
    })
  },
  TimeChange(e) {
    this.setData({
      time: e.detail.value
    })
  },
  timeSubmit(e){
    let medicineTime={
      pid:app.globalData.patientId,
      startTime:''
    };
    medicineTime.startTime = util.formatDate(new Date())+' '+e.detail.value.time+':00';
    // var a = new Date();
    
    // console.log()
    wx.request({
      url: app.globalData.url +'/wxpatient/getMedicineTime',
      header:{
        token:app.globalData.token
      },
      data: medicineTime,
      method:'post',
      success:res=>{
        console.log(res)
      }
    })
    console.log(e)
  },
  trackSubmit(e){
    var record = this.data.record;
    record.sign = 0;
    wx.request({
      url: app.globalData.url + '/wxpatient/updateSymptomsOrTrack',
      data: {
        record:
          JSON.stringify(record)
      },
      method: 'post',
      header: {
        token: app.globalData.token,
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
      },
      success: res => {
        this.setData({
          isUpdata: true
        })
      }
    })
  },
  hideTip(e){
    this.setData({
      isUpdata:false
    })
  }
})