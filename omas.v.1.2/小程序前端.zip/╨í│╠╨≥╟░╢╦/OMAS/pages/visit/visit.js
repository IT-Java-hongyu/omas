// pages/visit/visit.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    record:{
      recId:'',
      pId:'',
      rSymptomsList:[{
        desc:'',
        nowDegree:'',
        recId:'',
        startDegree:'',
        symId:''
      }],
      docId:'',
      descDetail:'',
      sign:'',
      status: '',
      date:''
    },
    change:['消失','轻微','严重','特别严重'],
    value:[],
    index:"",
    isUpdata:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(app.globalData.token)
    // console.log(app.globalData.url)
    wx.request({
      url: app.globalData.url+'/wxpatient/searchSymptoms',
      data:{
        pid: app.globalData.patientId
      },
      header:{
        token: app.globalData.token,
        // 'context-Type':'text/plain'
      },
      success:res=>{
        var rec = res.data;
        this.setData({
          record:rec
        })
        console.log(this.data.record);
        // console.log(this.data.symptomsList);
      }
    })
  },
  submit:function(e){
    console.log('debug')
    // console.log(this.data.record)
    var record = this.data.record;
    record.sign = 1;
    // record.rSymptomsList = JSON.stringify(this.data.record.rSymptomsList);
    console.log(record)
    wx.request({
      url: app.globalData.url + '/wxpatient/updateSymptomsOrTrack',
      data:{
        record:
        JSON.stringify(record)
      },
      method:'post',
      header: {
        token: app.globalData.token,
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
       // 'context-Type': 'text/plain'
      },
      // method:'post',
      success:res=>{
        this.setData({
          isUpdata:true
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  showModal(e) {
    console.log(e)
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
    this.sen(e.target.id)
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  true(e){
    this.setData({
      modalName: null
    })
  },
  handleChange(e){
    // console.log('debug'+e.detail.value)
    var value= this.data.value;
    var index = this.data.index;
    value[index] = e.detail.value;
    let record = this.data.record;
    record.rSymptomsList[index].nowDegree = e.detail.value;
    this.setData({
      value: value,
      record: record
    })
    console.log(this.data.record)
  },
  sen(e){
    this.setData({
      index:e 
    })
  },
  hideTip(e) {
    this.setData({
      isUpdata: false
    })
  }
})