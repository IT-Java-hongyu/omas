const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isUpdata:false,
    patient:{},
    region: ['广东省', '广州市', '海珠区'],
    date:'2019-12-12'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getPatientInformation()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  getPatientInformation:function(){
    var that = this;
    wx.request({
      url: app.globalData.url + '/wxpatient/getPatientById',
      header: {
        token: app.globalData.token
      },
      method: 'post',
      data: app.globalData.patientId,
      success: res => {
        console.log(res)
        that.setData({
          patient: res.data.message.patient
        })
        console.log(res)
        console.log
      },
    })
  },
  formSubmit(e){
    console.log(e)
    var patient = this.data.patient
    patient.patientName = e.detail.value.patientName;
    patient.patientBirthday = e.detail.value.patientBir;
    patient.patientSex = e.detail.value.patientSex?1:2;
    patient.patientAddress = e.detail.value.patientAdd[0] + e.detail.value.patientAdd[1]+e.detail.value.patientAdd[2];
    patient.patientPhone = e.detail.value.patientPhone;
    if (patient.patientName==""){
      wx.showModal({
        title: '姓名不能为空……',
        content: '',
      })
    } else if (patient.patientPhone==''){
      wx.showModal({
        title: '电话号码不能为空……',
        content: '',
      })
    }else{

    
      wx.request({
        url: app.globalData.url +'/wxpatient/updataPatient',
        data:{
          patient:this.data.patient
          },
        method:'post',
        header:{
          token:app.globalData.token
        },
        success:res=>{
          this.setData({
            isUpdata: false
          })
        }
      })
      this.getPatientInformation();
    }
  },
  
  updata(e){
    this.setData({
      isUpdata:true
    })
  }
})