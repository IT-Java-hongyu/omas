// pages/osam/bound/bound.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cardInform:{
      patientId: app.globalData.patientId,
      cardId:''
    },
    isCard:false,
    isShow:false,
    showMessage:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setCard()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  setCard:function(){
    var that = this;
    var cardInform = that.data.cardInform;
    cardInform.patientId = app.globalData.patientId;
    console.log(cardInform)
    wx.request({
      url: app.globalData.url+'/wxpatient/card',
      data:cardInform,
      header:{
        token:app.globalData.token
      },
      method:'post',
      success:res=>{
        console.log(res)
        if (res.data.message==""){
          that.setData({
            isCard:true
          })
        }else{
          console.log(cardInform)
          cardInform.cardId = res.data.message
          that.setData({
            cardInform: cardInform
          })
          console.log(that.data.cardInform)
        }
      }
    })
  },
  update(e){
    this.setData({
      isCard:true
    })
  },
  formSubmit(e){
    console.log(e)
    var that = this;
    var cardInform = that.data.cardInform;
    console.log(cardInform)
    cardInform.cardId = e.detail.value.cardId;
    wx.request({
      url: app.globalData.url+'/wxpatient/card',
      data: cardInform,
      header: {
        token: app.globalData.token
      },
      method: 'post',
      success:res=>{
        that.setData({
          isShow:true,
          showMessage:res.data.message,
          isCard:false
        })
      }
    })
  },
  hideTip(e){
    this.setData({
      isShow:false
    })
  }
})